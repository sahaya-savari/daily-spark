import{a as e,i as t,n,t as r}from"./jsx-runtime-Wy9s6hX0.js";import{p as i}from"./index-BTVBvwC9.js";var a=`zm/4kdZU8R2/FqUD5EeIEeE+y/5RMJm4h0/XnPd+IaT/eZE53CbzO8UMZNohqUIUnOZErtkGwDVzplwBQGqxTAVbvBaBKM+LYes9dphj+bRYkGkdsNcDbc4Sd2AO3FnRQxzlp1p9EabYhjSWU+2HwVsKazN+oluX1Sa7fOCdJYThmDPoZaJGri/Yhc0qwhl11irrmzx29Eky8K9BvDSICpfFZwe3z49NKHP5vwdvMvh50Jf1GspD6AqI9TTOVvS5IXutSsQI+W8RVLUN7jqkSQCpUwzJix/An4Qo55Vt9axSLIX2SDHvaOSzHEaj4h2sSim1VON3KWuqSGcakA1wPVP7DdR2O4jB555CbYtd0ZPyw4TeYqxV5GMY0lECyCVm2OuhHnabFsICWYzNfmC9jhHeggE8k7b6F8TdsU7HqNmfZ5Al7LQaXCt//CPcsx97MGpBI/YzD5U/u3KmgutGtw8+XL3XVat9PaXrNhDZQFrvZ6fDY9IOf1qXOnn9MIMS0rs4X51P45bTBcSqSwj4WuEPvJx7wtlr/g3bMF4YmXONzn8FN/okzeBuJmb+lSXMnC5F+COiTtsq8B2hCWXnRXUa8MkEgTK2SnU5ZpmDxESih9ZRGESlgiiYSvOswt8y/SCw5JRjiEYLkcarT7RyBH7YE3WK6DS9jG7OW9q6kyqriktyr/5qEd6R7xnmLWsXuCv6cLPuAlPOsncgiT8NYaBSbkTGFOi6V/UdfAzmOfLCT7LhVQprp0gEtkKAH1H4XOMQ2T8hochdJa/MV6jX7nldBzaRYcg55WMK0Vjseta+Cu4keK4wc6Q31kbDhl6oImmPNp7K/hnX7ZIv9J3MAb41o49ev4U1935FDok8BJNBzZ++3iaIohuA+J4ut5QiQomo2ZpN0xDsg2OgK9sSkz/7Br4feDuEYSRzqwxsO34cas8o8RXjUAGgwHD10GOyJeKARxJ1+1u8NUnBawVP+XLOWTkD/2GSJLgA+nCuUOK3fdVK71u2m8hKvedZ1q7pjvlJgLFCcJTVZeUsmh19/1MOZvSqy0AJ643aFIfgo8YyEfGEabU0x0faVpMbzDFsDVgsqonTAC72Dok9GJEmTacOu2UGns0orzwZWbZHxjSiwpAvVxiTsW0iqlf1Pxpij7Elw5cb6Wx9ojPmRYP2oMfpl2cTQehxU6bbZsD+dNE3hSXsx1T7DXjyjNd36hKLbO0e03rpZNdLy3gwmnO33EnleEHXVacH4xTOabQKYCOGPRr5y4GvldUheTGgRAVfwuBxQJIuhWG8S6QFOKlc0QFIrD2auyEznwHwvQzQKoECoV4L9y2EQLpYhSKb7b5I3rJ3u08qXhU8uvEM4oGz7xlWnNIbs9k54xbLbPeRKOWzhWHgC035f+Jdh0Zm7U+u/DbIi6tvwfCVMPzETzJ7lwRWLpwJ4L/9bYxbl8lSK5JCrQP0XncTpo4qgFYevHRPMfsWwHGKqRI/tB7ZohaSaCNy6Uch1A5gHnSmA27fF8fsa8/0jXSgSAjRJD9sEt54/M4ziUTD709o/bXhRdUTncl5lyzxNtFpx5P/NnvLOrrYnhC2aJpO2rLqR8+RsV84p4UUQWIwHNl8nOqz96G+YA2AZ7fhKZIA0juWCqqF8mcIQ9pVsANY7ilQbgazVPUIRIRZ3jH+gTuMF2Y28ieH/0sjt+epx+xYsDNRAYQ3IJg95SGfC1yscrsfXnkpVTi96qMcbuaPpHoVrdGW6SmMY8HzH43JAq4mxeGhfxFVyQd525JUA4JAjhTFddBj2lHKqb9T9nrWNvVJnfHJ5LOTIlmEudA9Ike734U+XRp03akScjyoSnnpXXEJUNi6luGpZcEybtMnt/dk5COmGY/yel0VkDFKxYkX2YEOPWkF/XfUL00Qgsj7ZDUP87bWoTVKzZTnvWMX00CX+LAjP20vGkL3DqDyUXULozx9/0iyCSvoz2/drxFopSpSwqaMTMsYq+eW9KlZBpHFoGoqUgB+/R5bLQj5iaMbvy+IZfXEg+qUWn60GY/dMM2UWLwv3nKjiEYImif+Vee4buse3C2fX0IBc2Iu3Xco6EV/zI3svmWu4X2bzjdY7X1M4ACfFVC00iThSjbFXK1JFtYFimbIOx+17l58wI81EJU4Wn+/cPWOu9scwUOdtFcK+hisPSSaC0C6TWolr9gNaqrIWt12OgRsyJftewH7g+lvm/FNEflZc8gzqQVF3nrO+60Z6QozzyRJoIXrFc+H2aZdcdpQ54tt1RXyxXVElP4eQo4pnPyriy8QaLsonWIttTwgwICf45YWUPHRb6EkTAJplEmvhVepe/8HVGs6I3RBLbkHecc0+CanjAKeIbwz03Tvtg9OzV30pFLgQdAaxlPirGLYMAVC03eNHVv2w4e74jrSYPEP5GU2u9SP+MCZ78qK96IbWrGDXzfdTuxgfqEHYjfYfh0/uIAgq41t8IYGcZAPR7GI/KgrvTywDDZgnil8vyGbQ8YWmHUqrU0CYhVQI2REvd8TRu+3aMqJC8RN34bAV5jicQrZN/YITK81pf0px+pswV0U3GjqlXjL7hdV9glr3H4osNpI7huD5K564JvqMI5rmswJfxstpjz0G7An+harLPCRxmR7vhjhX9RDf1iVGyx9SJ0CUtUhRW+x142qMrlP+YpcCcRnoi7VObgOctMB/jmrWOWU+m3TWZduRJJ1ScFeQhOhVOqSdiSWFbfzOtuy6MqI9y+EquGQDT5zS+6VAG8746t9PvNWHIxcyUyugVUjeNIyTK8Rgrgw78kN5tQBgrD/KtIdPrfMUuNtAKNSDG0gOrFwwQlbMf3AJMsXX9a+HZYs0xmRynCm+yyXHui53ZYVu2TdJ0jmBH1UtTdooCDgb0mIqmf6CYKsNc92jD70p1zfGUzzo9CBYZrleziig+9Va/1LvQ3qRgV90T5lEkhp+IMDnMqOYqPcIJyG9FPMOJm/A+MtTKMm8WAd5sJmlcgKesuZKm0bRq0EUrP7J0sUzJ0EqGCBKrjYaar2jaXILqk/6nM4/xi/QV7REym4jWIX61h3wZBr10WZtkwn1hpOiv9AY+eLuPAv3IsSa8DddbQ6h+E02p5UjRYwVgnffxrVXL8hU614K5TorXNK3gf1fqE11Q/zGbx8Bob8oXztNbcmpwO+Tw18ZsNC55hZBpAl7VIas2oU8zrix7F0OlLtjgykh9YGyfJsCDT8g6UxT88etIxGrVo57skzXQu/klfmctKAON2Vzxakdh85rvRI0WXCefZGzXOaXYEe68CeajHNRPNokTtQtIpWxhBkvZNvQPhjKeJzphNq4K9FLGcGmxhM9p8eXfw0U/DRgMkve6cNnSyRAK0kvQf/SJUoAbT8el0ZLt6jFM8m45k91OkSqd0GfM2SIsRTniB10vms28VhtS5sykSuhLcHYaIUaeUf/EHKXeaCUdU0p2/QX+VNHqjE6IC5W3vrRHW3HnpJKFzAlk+2C/5/1z/rixNKgTwliN8Q6osFaCHflyr6T5O6Vopw3B2jOe5oi90QOYPFcpQ8CZpBDvwglK0GWvSPsf2GNR3xOGpKLJMBvVWdwg1y7EeceD68oe3HSnC+O9oCzzqsCLZNdMYOsiBXu+yjEy7h0GuzVdRvwzRl38EvZwLKbeOkd9Od5a5f9W4j5GH0pcsAslnPFVR8OY8T5FqlhSjiZO81jfkrhkX2lnokUfmuhVAm9YwsoEvvhhWbTdalQBRRyARXH4MRwzmohzYbilQzafEgh/ss2gz1soAcarVLfBeY0hRgqNxwxQNB1ZlkQATsvhJ05AS2HMxBeOgjgfCbuiuO7LTOQ3neDtS5otgjv5XTN6thnLdnUZ4vyfcM6cSoQ3e55QdUnzHisnENudx6nl+UNcdjfJZb9rURxlgweWT6R3MxY/olmV5HeAZB6H8VTnbjG0N/0yLndkmaOZJYLf5VJ5Q9yh1kjFLzN4kcyytF2q9O+DzcKaE2aZGo3hzSEazYCaePULXpJ/+VbKxc+rgLkL7sApY8vgfeYNUUbMsEhdBr8YC0/ROmJcPmV2yq/hSBH54Pv3EB2VD/B0iwhjuWVoLgGsoDgWXBTtIML6BA2GpRK8xw/V6LsR99uu+OseEYq0wr13ZE0GJ6m0PuC3jEYuvOhlDzi7B6JcNs8VvF6iC4N2/yPqzZM4n1unHhhCal94etShmlLEH5n000HkhkOMQPpFkFmegbsAAwuJBQMphGK2mpOiDQP+WKN50oAHFF+F/AiVUfmRJZIj6YFlTLBzplEePGdunCaQDQd6Xrf5n4cInuyDeGTvrLc9sizeSsBbngFulmmApbuBHdfrbZpI4MKaDfdPCy3nvG7WSy8nnD25M1WJcMUYQv8VbCC9YmU98xGapuvC1ejEekYoISbft8V5XHTL32pXHKTfwxXBbIdu5ECL47aA6jTQSLLUOXUiC5fPQn0bLilK0VjT9gtAKTu0lh4ArUoQ/iF/Y7vE6SN9cIeCqCGEYtlhxmn4c+3lKt0WKQJ8yM9zS25nTbD678YAOoR3EXPV8k4G/6nc08Z9V9/COUd+w9b69Wm+kmzBuiQvmr2mfQ7HrUrgnmuiKZM4MY/apGH27TWKAYumsriEHmxo7cpP98zkm4LRp19KkpD6NAVrUax48l0AKIaK/vcMFhDjuNswNXOPBHd1r6BW3kwlR25VycDIMoykzqn8x0FjNjIlgGvJ4Qh1nljBNW7MWKzvMsZ0v+uXsy3UULU40h4pnuUiicvoQhx6cujs62SyueAb0psuhA/2WPOgpV35i2ferMOXEp89Y7r8lGmnQ4XwJ7oN+ECF5C86HDhdcyuE94GcRu/hfaapIP2GY/fw/wiD/XkUxywZsD2X73sSVJ9glDm4noTGSYegxpLuO7HK3bQxfDMajXmBBwJ1/9pwDTOKvYhkVhpD33UbMd7aZX0q9l+RDNMhxasC3EG2GKyWmnw2AS1LMBwyb9oNAGg07qaryTWedsIL1O27ATP3tmkPdeCDSz5AvKLHHihjDHGHIzGn6p84rfd+tLbqg82hA2giL7MqWAPdxXuk2OYvidL4Ej+hCLPvd5kjfvicnnKsAcf5vwIpFLgLmfBEicX/KQ4MVUO2gIuT6YENST8nS37VfVsXNQGPWSchU03x8+vwuqXM1LtdEKWsYZaEueD1aiQt1RxXHUZPIVW8/4dAu1JESd5yLAUJ8f+4RaJwhOnxePQgWV5c9mK6jugqTGeVPU8Dicdiekgi7mpdQtvHLS8m20ETqmAjGa3CePOKrYUW68BnaO7X3bY8E247DNhzHbbsjxXyaiRb8Oy0NnB+eQahSK5gDbYvKYRwN++x6NPgQukPx7Vu3CdUCyZsUcgi79iVrVphNDLawAdZpDbP5buiGnNYC6CXiK5F4i+6s2JLVHxGUyuU4TwnC1XZpO6bB8zGDWJ7mIHVP/hhLwSuSZxhfrMg==`,o=(e,t,n)=>({ranks:t,size:e,steps:n,thresholds:Float32Array.from(t,e=>(e+.5)/n)}),s=e=>{let t=new Uint8Array(e*e);for(let n=0;n<e;n+=1)for(let r=0;r<e;r+=1){let i=0;for(let t=1;t<e;t*=2){let e=Math.floor(r/t)%2,a=Math.floor(n/t)%2;i=i*4+2*((e+a)%2)+a}t[n*e+r]=i}return t},c=e=>{let t=atob(e);return Uint8Array.from(t,e=>e.codePointAt(0)??0)},l=o(2,s(2),4),u=o(4,s(4),16),d=o(8,s(8),64),f=o(64,c(a),256),p=e=>{switch(e){case`bayer2`:return l;case`bayer4`:return u;case`bayer8`:return d;case`blue-noise`:return f;default:return e}},m=(e,t)=>(Math.floor(e)%t+t)%t,h=(e,t,n)=>{let r=p(e);return r.thresholds[m(n,r.size)*r.size+m(t,r.size)]??0},g=(e,t,n,r)=>r>h(e,t,n),_={blue:`oklch(0.64 0.16 245)`,green:`oklch(0.68 0.16 152)`,grey:`oklch(0.6 0 0)`,ink:`oklch(0.6 0.2 270)`,orange:`oklch(0.72 0.16 58)`,pink:`oklch(0.66 0.19 352)`,purple:`oklch(0.62 0.2 302)`,red:`oklch(0.62 0.21 26)`},v={blue:`--dither-color-blue`,green:`--dither-color-green`,grey:`--dither-color-grey`,ink:`--dither-ink`,orange:`--dither-color-orange`,pink:`--dither-color-pink`,purple:`--dither-color-purple`,red:`--dither-color-red`},ee=[`--dither-paper`,`--dither-ink`],y=e=>Object.hasOwn(v,e),b=e=>y(e)?`var(${v[e]}, ${_[e]})`:e.startsWith(`--`)?`var(${e})`:e,x=r(),S=[`off`,`low`,`high`],C=(e,t,n)=>{let r=``;for(let i=0;i<t;i+=1){let t=-1;for(let a=0;a<=e;a+=1){let o=a<e&&n(a,i);o&&t===-1?t=a:!o&&t!==-1&&(r+=`M${t} ${i}h${a-t}v1h${t-a}z`,t=-1)}}return r};C(4,4,(e,t)=>t%2==0&&(e+t/2)%2==0),C(4,4,(e,t)=>(e+t)%4==3);var w={high:{blur:18,strength:.55},low:{blur:10,strength:.3}},te=(e,t)=>{if(t===`off`)return;let{blur:n,strength:r}=w[t],i=t=>`color-mix(in oklab, ${b(e)} calc(var(--dither-bloom, 1) * ${Math.round(t*100)}%), transparent)`;return`drop-shadow(0 0 ${Math.round(n/3)}px ${i(r*1.4)}) drop-shadow(0 0 ${n}px ${i(r)})`},T=(e,t)=>{let n=te(e,t);return n===void 0?{}:{filter:n}},E=e(n(),1),D=3,O=null,k=()=>{if(!O){let e=document.createElement(`canvas`);e.width=1,e.height=1,O=e.getContext(`2d`,{willReadFrequently:!0})}return O},A=(e,t)=>{let n=t??document.documentElement,r=document.createElement(`span`);r.style.color=b(e),r.style.display=`none`,n.append(r);let{color:i}=getComputedStyle(r);r.remove();let a=k();if(!a)return[0,0,0,1];a.clearRect(0,0,1,1),a.fillStyle=i,a.fillRect(0,0,1,1);let[o=0,s=0,c=0,l=0]=a.getImageData(0,0,1,1).data;return[o/255,s/255,c/255,l/255]},ne=e=>{let t=e??document.documentElement,n=Number.parseFloat(getComputedStyle(t).getPropertyValue(`--dither-cell`));return Number.isFinite(n)&&n>0?n:D},j=new Set,M=null,N=e=>(j.add(e),M||(M=new MutationObserver(()=>{for(let e of j)e()}),M.observe(document.documentElement,{attributeFilter:[`class`,`style`,`data-theme`],attributes:!0})),()=>{j.delete(e),j.size===0&&(M?.disconnect(),M=null)}),P=[`--dither-ink`,`--dither-paper`];function F(e,t=P){let[n,r]=(0,E.useState)(null),i=t.join(`|`);return(0,E.useEffect)(()=>{let t=i===``?[]:i.split(`|`),n=()=>r(t.map(t=>A(t,e?.current)));return n(),N(n)},[e,i]),n}var I=`(prefers-reduced-motion: reduce)`,L=e=>{let t=window.matchMedia(I);return t.addEventListener(`change`,e),()=>t.removeEventListener(`change`,e)},R=()=>(0,E.useSyncExternalStore)(L,()=>window.matchMedia(I).matches,()=>!1),z=e=>(document.addEventListener(`visibilitychange`,e),()=>document.removeEventListener(`visibilitychange`,e)),B=()=>(0,E.useSyncExternalStore)(z,()=>document.visibilityState===`visible`,()=>!0),V=(e,{rootMargin:t=`120px`}={})=>{let[n,r]=(0,E.useState)(!1);return(0,E.useEffect)(()=>{let n=e.current;if(!n)return;if(typeof IntersectionObserver>`u`){r(!0);return}let i=new IntersectionObserver(([e])=>r(e?.isIntersecting??!1),{rootMargin:t});return i.observe(n),()=>i.disconnect()},[e,t]),n},H={current:null},U=.1,W=(e,{target:t,enabled:n=!0,fps:r=30,stillTime:i=0}={})=>{let a=(0,E.useRef)(e);(0,E.useEffect)(()=>{a.current=e});let o=R(),s=B(),c=V(t??H),l=!t||c,u=o||!n,d=!u&&s&&l,f=(0,E.useRef)(0);return(0,E.useEffect)(()=>{if(u){a.current(i,0);return}if(!d)return;let e=1e3/Math.max(1,r),t=0,n=performance.now(),o=-1/0,s=r=>{t=requestAnimationFrame(s);let i=Math.min((r-n)/1e3,U);if(n=r,f.current+=i,r-o>=e-2){let e=Math.min((r-o)/1e3,U);o=r,a.current(f.current,e)}};return t=requestAnimationFrame(s),()=>cancelAnimationFrame(t)},[u,d,r,i]),u?`static`:d?`running`:`paused`},G=/\/\*[\s\S]*?\*\/|\/\/[^\r\n]*/g,re=/^[ \t]*#/m,ie=/^\s*(?:(?:lowp|mediump|highp|const|uniform)\s+)*struct\b/,ae=/^\s*precision\b/,oe=/\d+\.\d*(?:[eE][-+]?\d+)?|\.\d+(?:[eE][-+]?\d+)?|\d+(?:[eE][-+]?\d+)?|[A-Za-z_]\w*|\+\+|--|<=|>=|==|!=|&&|\|\||\^\^|[-+*/]=|\S/g,K=e=>{let t=e.replaceAll(G,` `),n=[],r=0,i=0,a=e=>{let r=t.slice(i,e).trim();i=e,r!==``&&n.push(r)};for(let e=0;e<t.length;e+=1){let n=t[e];n===`{`?r+=1:n===`}`?(--r,r===0&&!ie.test(t.slice(i,e))&&a(e+1)):n===`;`&&r===0&&a(e+1)}return a(t.length),n},q=e=>e.match(oe)?.join(` `)??``,J=e=>re.test(e.replaceAll(G,` `)),se=(e,t)=>{if(J(e)||J(t))return t;let n=new Set(K(e).map(q));return K(t).filter(e=>ae.test(e)||!n.has(q(e))).join(`
`)},ce=`
float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

vec3 dither_permute(vec3 x) {
  return mod(((x * 34.0) + 1.0) * x, 289.0);
}

float snoise(vec2 v) {
  const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
  vec2 i = floor(v + dot(v, C.yy));
  vec2 x0 = v - i + dot(i, C.xx);
  vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod(i, 289.0);
  vec3 p = dither_permute(dither_permute(i.y + vec3(0.0, i1.y, 1.0)) + i.x + vec3(0.0, i1.x, 1.0));
  vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy), dot(x12.zw, x12.zw)), 0.0);
  m = m * m;
  m = m * m;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);
  vec3 g;
  g.x = a0.x * x0.x + h.x * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}

float fbm(vec2 p) {
  float sum = 0.0;
  float amp = 0.5;
  mat2 rotate = mat2(0.8, -0.6, 0.6, 0.8);
  for (int i = 0; i < 4; i++) {
    sum += amp * snoise(p);
    p = rotate * p * 2.02 + vec2(11.3, 4.7);
    amp *= 0.5;
  }
  return clamp(0.5 + 0.5 * sum / 0.9375, 0.0, 1.0);
}

vec3 spectrum(float h) {
  vec3 rgb = clamp(abs(mod(fract(h) * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
  return rgb * rgb * (3.0 - 2.0 * rgb);
}

vec4 dither_paletteEntry(float index) {
  return texture2D(u_palette, vec2((index + 0.5) / u_paletteSize, 0.5));
}

vec4 paletteColor(float x) {
  float last = u_paletteSize - 1.0;
  float scaled = clamp(x, 0.0, 1.0) * (last - 1.0);
  float index = floor(scaled);
  vec4 from = dither_paletteEntry(1.0 + index);
  vec4 to = dither_paletteEntry(min(2.0 + index, last));
  return mix(from, to, scaled - index);
}

vec4 dither_rgba(vec3 color) {
  return vec4(color, 1.0);
}

vec4 dither_rgba(vec4 color) {
  return color;
}
`,le=`
attribute vec2 a_position;
void main() {
  gl_Position = vec4(a_position, 0.0, 1.0);
}
`,ue=/^[A-Za-z][A-Za-z0-9_]*$/,de={1:`float`,2:`vec2`,3:`vec3`,4:`vec4`},fe=e=>typeof e==`number`?1:e.length,pe=e=>Object.keys(e).toSorted().flatMap(t=>{let n=e[t];return n===void 0?[]:!ue.test(t)||t.startsWith(`u_`)?(console.error(`[dither-core] uniform "${t}" skipped: names must be GLSL identifiers and not start with "u_"`),[]):[{name:t,size:fe(n)}]}),me=`
  float scaled = tone * (u_paletteSize - 1.0);
  float index = floor(scaled);
  index = min(index + step(threshold, scaled - index), u_paletteSize - 1.0);
  vec4 color = dither_paletteEntry(index);`,he=`
  float ink = min(floor(tone) + step(threshold, fract(tone)), 1.0);
  vec4 color = ink > 0.5
    ? dither_rgba(colorField(uv, u_resolution, u_time))
    : dither_paletteEntry(0.0);
  color = clamp(color, 0.0, 1.0);`,ge=(e,t,n)=>`
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_levels;
uniform sampler2D u_thresholds;
uniform float u_matrixSize;
uniform float u_rankStep;
uniform sampler2D u_palette;
uniform float u_paletteSize;
${n.map(({name:e,size:t})=>`uniform ${de[t]} ${e};`).join(`
`)}
${ce}
${e}
${t===void 0?``:se(e,t)}

void main() {
  vec2 cell = floor(gl_FragCoord.xy);
  vec2 uv = (cell + 0.5) / u_resolution;
  float tone = clamp(field(uv, u_resolution, u_time), 0.0, 1.0);
  float steps = u_levels - 1.0;
  tone = floor(tone * steps + 0.5) / steps;

  // Ranks are stored as rank * (256 / steps), so this threshold is exactly
  // (rank + 0.5) / steps, halfway between two tones.
  vec2 at = (mod(cell, u_matrixSize) + 0.5) / u_matrixSize;
  float stored = floor(texture2D(u_thresholds, at).r * 255.0 + 0.5);
  float threshold = (stored + 0.5 * u_rankStep) / 256.0;

${t===void 0?me:he}
  gl_FragColor = vec4(color.rgb * color.a, color.a);
}
`,Y=(e,t,n)=>{let r=e.createShader(t);if(!r)return null;if(e.shaderSource(r,n),e.compileShader(r),!e.getShaderParameter(r,e.COMPILE_STATUS)){if(!e.isContextLost()){let t=e.getShaderInfoLog(r)??``;console.error(`[dither-core] shader failed to compile`,t),t.includes(`already has a body`)&&console.error("[dither-core] a function is defined twice. `field` and `colorField` compile into one shader: give helpers different names, or define a shared helper once, in `field`, and call it from both.")}return e.deleteShader(r),null}return r},X=e=>{let t=e.createTexture();return e.bindTexture(e.TEXTURE_2D,t),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),t},_e=(e,{field:t,colorField:n,specs:r})=>{let i=Y(e,e.VERTEX_SHADER,le),a=Y(e,e.FRAGMENT_SHADER,ge(t,n,r)),o=e.createProgram();if(!i||!a||!o)return null;if(e.attachShader(o,i),e.attachShader(o,a),e.linkProgram(o),e.deleteShader(i),e.deleteShader(a),!e.getProgramParameter(o,e.LINK_STATUS))return e.deleteProgram(o),null;e.useProgram(o);let s=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,s),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),e.STATIC_DRAW);let c=e.getAttribLocation(o,`a_position`);e.enableVertexAttribArray(c),e.vertexAttribPointer(c,2,e.FLOAT,!1,0,0);let l=t=>e.getUniformLocation(o,t),u=l(`u_resolution`),d=l(`u_time`),f=l(`u_levels`),p=l(`u_matrixSize`),m=l(`u_rankStep`),h=l(`u_paletteSize`);e.uniform1i(l(`u_thresholds`),0),e.uniform1i(l(`u_palette`),1);let g=r.map(e=>({...e,location:l(e.name)})),_=X(e),v=X(e);return e.pixelStorei(e.UNPACK_ALIGNMENT,1),{dispose:()=>{e.deleteTexture(_),e.deleteTexture(v),e.deleteBuffer(s),e.deleteProgram(o)},draw:({columns:t,rows:n,time:r,levels:i,uniforms:a})=>{e.viewport(0,0,t,n),e.uniform2f(u,t,n),e.uniform1f(d,r),e.uniform1f(f,i);for(let t of g){let n=a[t.name];n!==void 0&&(typeof n==`number`?e.uniform1f(t.location,n):n.length===2?e.uniform2f(t.location,n[0],n[1]):n.length===3?e.uniform3f(t.location,n[0],n[1],n[2]):e.uniform4f(t.location,n[0],n[1],n[2],n[3]))}e.drawArrays(e.TRIANGLES,0,3)},setMatrix:t=>{let n=256/t.steps,r=Uint8Array.from(t.ranks,e=>e*n);e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,_),e.texImage2D(e.TEXTURE_2D,0,e.LUMINANCE,t.size,t.size,0,e.LUMINANCE,e.UNSIGNED_BYTE,r),e.uniform1f(p,t.size),e.uniform1f(m,n)},setPalette:t=>{let n=new Uint8Array(t.length*4);for(let[e,r]of t.entries())n.set(r.map(e=>Math.round(e*255)),e*4);e.activeTexture(e.TEXTURE1),e.bindTexture(e.TEXTURE_2D,v),e.texImage2D(e.TEXTURE_2D,0,e.RGBA,t.length,1,0,e.RGBA,e.UNSIGNED_BYTE,n),e.uniform1f(h,t.length)}}},Z=new Set,Q=(e,t)=>{e.active=t,e.setActive(t)},ve=e=>{let t=null;for(let n of e)(!t||n.lastSeen<t.lastSeen)&&(t=n);return t},ye=e=>{if(e.active)return;let t=[...Z].filter(e=>e.active);if(t.length>=8){let n=t.filter(e=>!e.onScreen),r=e.onScreen?ve(n):null;if(!r)return;Q(r,!1)}Q(e,!0)},$=e=>{if(!e.active)return;Q(e,!1);let t=[...Z].filter(e=>e.near&&!e.active),n=t.filter(e=>e.onScreen),r=ve(n.length>0?n:t);r&&Q(r,!0)},be=()=>[...Z].some(e=>e.onScreen&&e.near&&!e.active),xe=e=>{let[t,n]=(0,E.useState)(!1);return(0,E.useEffect)(()=>{let t=e.current;if(!t)return;let r={active:!1,lastSeen:0,near:!1,onScreen:!1,setActive:n};Z.add(r);let i=new IntersectionObserver(([e])=>{r.near=e?.isIntersecting??!1,r.near?(r.lastSeen=performance.now(),ye(r)):$(r)},{rootMargin:`200px`}),a=new IntersectionObserver(([e])=>{r.onScreen=e?.isIntersecting??!1,r.onScreen&&r.near?(r.lastSeen=performance.now(),ye(r)):!r.onScreen&&r.active&&be()&&$(r)});return i.observe(t),a.observe(t),()=>{i.disconnect(),a.disconnect(),Z.delete(r),$(r)}},[e]),t},Se={},Ce=e=>Math.min(256,Math.max(2,Math.round(e))),we=`absolute top-0 left-0 block opacity-100 transition-opacity duration-700 ease-out [image-rendering:pixelated] group-data-[state=fallback]/dither:opacity-0 group-data-[state=fallback]/dither:duration-0 motion-reduce:transition-none`,Te=({field:e,colorField:t,uniforms:n=Se,matrix:r=`bayer4`,levels:a,cell:o,palette:s=ee,speed:c=1,animate:l=!0,fps:u=30,stillTime:d=0,fallback:f,className:m,"aria-hidden":h=!0,ref:g,..._})=>{let v=(0,E.useRef)(null),y=e=>{if(v.current=e,typeof g==`function`)return g(e);g&&(g.current=e)},S=(0,E.useRef)(null),C=(0,E.useRef)({columns:0,rows:0}),w=(0,E.useRef)(d),[te,T]=(0,E.useState)(!1),D=(0,E.useRef)(!1),O=xe(v),k=p(r),j=Ce(a??k.steps+1),M=s.join(`|`),P=pe(n),F=P.map(({name:e,size:t})=>`${e}:${t}`).join(`,`),I=e=>{D.current!==e&&(D.current=e,T(e))},L=(0,E.useRef)({levels:j,map:k,paletteKey:M,speed:c,uniforms:n}),z=(0,E.useRef)(null);(0,E.useEffect)(()=>{L.current={levels:j,map:k,paletteKey:M,speed:c,uniforms:n},z.current=()=>{let e=S.current,{columns:t,rows:n}=C.current;e&&t!==0&&n!==0&&(e.draw({columns:t,levels:L.current.levels,rows:n,time:w.current,uniforms:L.current.uniforms}),I(!0))}});let B=R(),V=(0,E.useRef)(!1);(0,E.useEffect)(()=>{V.current=!1},[d]);let H=W((e,t)=>{t>0?(w.current+=t*L.current.speed,V.current=!0):(B||!V.current)&&(w.current=e),z.current?.()},{enabled:l,fps:u,stillTime:d,target:v});return(0,E.useEffect)(()=>{let n=v.current;if(!n||!O)return;let r=document.createElement(`canvas`);r.className=we;let i=r.getContext(`webgl`,{alpha:!0,antialias:!1,depth:!1,powerPreference:`low-power`,premultipliedAlpha:!0,stencil:!1});if(!i)return;n.append(r);let a=()=>L.current.paletteKey.split(`|`).map(e=>A(e,n)),s=()=>{S.current?.dispose();let n=_e(i,{colorField:t,field:e,specs:P});S.current=n,n?.setMatrix(L.current.map),n?.setPalette(a())},c=()=>{let e=window.devicePixelRatio||1,t=o??ne(n),i=Math.max(1,Math.round(t*e))/e,a=getComputedStyle(n),s=Number.parseFloat(a.width)||n.offsetWidth,c=Number.parseFloat(a.height)||n.offsetHeight,l=Math.max(1,Math.ceil(s/i)),u=Math.max(1,Math.ceil(c/i));C.current={columns:l,rows:u},r.width=l,r.height=u,r.style.width=`${l*i}px`,r.style.height=`${u*i}px`,z.current?.()},l=()=>{S.current?.setPalette(a()),z.current?.()},u=e=>{e.preventDefault(),S.current=null,I(!1)},d=()=>{s(),z.current?.()};s(),c();let f=new ResizeObserver(c);f.observe(n);let p=N(l);return r.addEventListener(`webglcontextlost`,u),r.addEventListener(`webglcontextrestored`,d),()=>{f.disconnect(),p(),r.removeEventListener(`webglcontextlost`,u),r.removeEventListener(`webglcontextrestored`,d),S.current?.dispose(),S.current=null,i.getExtension(`WEBGL_lose_context`)?.loseContext(),r.remove(),I(!1)}},[e,t,F,o,O]),(0,E.useEffect)(()=>{S.current?.setMatrix(k)},[k]),(0,E.useEffect)(()=>{let e=v.current;e&&S.current?.setPalette(M.split(`|`).map(t=>A(t,e)))},[M]),(0,E.useEffect)(()=>{H!==`running`&&z.current?.()}),(0,x.jsx)(`div`,{ref:y,"aria-hidden":h,"data-state":te?H:`fallback`,className:i(`group/dither pointer-events-none relative overflow-hidden`,m),..._,children:(0,x.jsx)(`div`,{"data-dither-fallback":!0,className:`absolute inset-0 opacity-0 transition-opacity delay-700 duration-0 group-data-[state=fallback]/dither:opacity-100 group-data-[state=fallback]/dither:delay-0`,children:f??(0,x.jsx)(`div`,{className:`absolute inset-0`,style:{backgroundColor:b(s[0])}})})})},Ee=t({DitherShader:()=>Te});export{T as a,S as i,W as n,b as o,F as r,g as s,Ee as t};