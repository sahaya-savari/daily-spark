import{C as e,c as t,g as n}from"./index-Bv0HlkeK.js";import{t as r}from"./site-faq-DnDcktFh.js";import{n as i,t as a}from"./SiteChrome-CNpOMQFP.js";import{t as o}from"./site-KdjI_zFN.js";import{t as s}from"./jsx-runtime-Wy9s6hX0.js";var c=s(),l=[`docs`,`getting-started`,`faq`,`backup-restore`,`design-system`];function u({text:e}){return(0,c.jsx)(`div`,{className:`space-y-6`,children:e.replace(/^#[^\n]*\n/,``).replace(/^(#{2,6} .+)$/gm,`
$1
`).trim().split(/\n\s*\n/).map((e,t)=>e.startsWith(`## `)?(0,c.jsx)(`h2`,{className:`pt-4 text-xl font-bold text-foreground`,children:e.slice(3)},t):e.startsWith(`- `)?(0,c.jsx)(`ul`,{className:`list-disc space-y-2 pl-5 text-muted-foreground`,children:e.split(`
`).map(e=>(0,c.jsx)(`li`,{children:e.replace(/^- /,``)},e))},t):(0,c.jsx)(`p`,{className:`whitespace-pre-line leading-7 text-muted-foreground`,children:e},t))})}function d({page:s}){let d=t[s];return(0,c.jsxs)(`div`,{className:`min-h-screen bg-background text-foreground`,children:[(0,c.jsx)(`a`,{href:`#main`,className:`sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-3 focus:z-[90] focus:rounded-lg focus:bg-ember focus:px-4 focus:py-3 focus:text-black`,children:`Skip to content`}),(0,c.jsx)(i,{}),(0,c.jsxs)(`main`,{id:`main`,tabIndex:-1,className:`mx-auto max-w-[1100px] px-4 py-12 outline-none sm:px-6 sm:py-20`,children:[(0,c.jsxs)(`header`,{className:`max-w-3xl border-b border-border pb-10`,children:[(0,c.jsx)(`p`,{className:`mb-4 font-mono text-xs font-semibold uppercase tracking-widest text-ember`,children:d.eyebrow}),(0,c.jsx)(`h1`,{className:`font-display text-4xl font-bold tracking-tight sm:text-5xl`,children:d.title}),(0,c.jsx)(`p`,{className:`mt-5 max-w-[62ch] text-base leading-7 text-muted-foreground sm:text-lg`,children:d.description})]}),(0,c.jsxs)(`div`,{className:`mt-10 grid gap-12 lg:grid-cols-[minmax(0,1fr)_240px] lg:gap-20`,children:[(0,c.jsxs)(`div`,{className:`min-w-0 space-y-9`,children:[s===`faq`&&(0,c.jsx)(`div`,{className:`divide-y divide-border`,children:r.map(({question:e,answer:t})=>(0,c.jsxs)(`details`,{className:`group py-5 first:pt-0`,children:[(0,c.jsx)(`summary`,{className:`cursor-pointer rounded-md py-2 text-lg font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember`,children:e}),(0,c.jsx)(`p`,{className:`mt-3 max-w-[65ch] leading-7 text-muted-foreground`,children:t})]},e))}),s===`design-system`&&(0,c.jsx)(`section`,{"aria-label":`Color palette`,className:`grid grid-cols-2 gap-4 sm:grid-cols-4`,children:[[`Ember`,`#EC894C`],[`Canvas`,`#0E0F12`],[`Surface`,`#18191E`],[`Warm text`,`#F5EBE1`]].map(([e,t])=>(0,c.jsxs)(`div`,{className:`overflow-hidden rounded-2xl border border-border`,children:[(0,c.jsx)(`div`,{className:`h-24`,style:{backgroundColor:t}}),(0,c.jsxs)(`div`,{className:`p-3`,children:[(0,c.jsx)(`p`,{className:`font-semibold`,children:e}),(0,c.jsx)(`p`,{className:`mt-1 font-mono text-xs text-muted-foreground`,children:t})]})]},e))}),d.sections.map(({title:e,text:t})=>(0,c.jsxs)(`section`,{children:[(0,c.jsx)(`h2`,{className:`text-xl font-bold sm:text-2xl`,children:e}),(0,c.jsx)(`p`,{className:`mt-3 max-w-[65ch] text-base leading-7 text-muted-foreground`,children:t})]},e)),s===`design-system`&&(0,c.jsxs)(`section`,{children:[(0,c.jsx)(`h2`,{className:`text-xl font-bold`,children:`App themes`}),(0,c.jsx)(`div`,{className:`mt-4 grid gap-4 sm:grid-cols-3`,children:Object.values(n).map(e=>(0,c.jsxs)(`div`,{className:`rounded-2xl border border-border p-4`,children:[(0,c.jsx)(`span`,{className:`mb-3 block size-8 rounded-full`,style:{backgroundColor:e.accent}}),(0,c.jsx)(`h3`,{className:`font-semibold`,children:e.name}),(0,c.jsx)(`p`,{className:`mt-2 text-sm leading-6 text-muted-foreground`,children:e.subtitle}),(0,c.jsx)(`code`,{className:`mt-3 block text-xs text-muted-foreground`,children:e.accent})]},e.id))})]}),s===`terms`&&(0,c.jsx)(u,{text:`# Terms & Conditions\r
\r
Last updated: 2026-02-01\r
\r
By using Daily Spark (the “App”), you agree to these Terms & Conditions.\r
\r
## 1. Use of the App\r
- The App is provided “as is” for personal use.\r
- You are responsible for how you use the App and for complying with applicable laws.\r
\r
## 2. No Warranty\r
THE APP IS PROVIDED “AS IS” AND “AS AVAILABLE”, WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.\r
\r
## 3. Limitation of Liability\r
TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR EXEMPLARY DAMAGES, OR ANY LOSS OF DATA, PROFITS, OR BUSINESS INTERRUPTION, ARISING OUT OF OR IN CONNECTION WITH YOUR USE OF THE APP.\r
\r
## 4. Data & Backups\r
- Daily Spark is an offline-first app.\r
- The App does not provide user accounts or cloud storage.\r
- Your data is stored on your device.\r
- You are responsible for maintaining your device security and creating backups (including exported backups) if you want to preserve your data.\r
\r
## 5. Changes to These Terms\r
These Terms may be updated in the repository over time. The “Last updated” date will reflect the latest version.\r
\r
## 6. Contact\r
For questions or concerns, please open an issue on the project repository.`}),s===`license`&&(0,c.jsx)(u,{text:`MIT License\r
\r
Copyright (c) 2026 Sahaya Savari F\r
\r
Permission is hereby granted, free of charge, to any person obtaining a copy\r
of this software and associated documentation files (the "Software"), to deal\r
in the Software without restriction, including without limitation the rights\r
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\r
copies of the Software, and to permit persons to whom the Software is\r
furnished to do so, subject to the following conditions:\r
\r
The above copyright notice and this permission notice shall be included in all\r
copies or substantial portions of the Software.\r
\r
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\r
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\r
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\r
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\r
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\r
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\r
SOFTWARE.\r
`}),s===`security`&&(0,c.jsx)(`a`,{href:`${o.repo}/security`,target:`_blank`,rel:`noreferrer`,className:`inline-flex min-h-11 items-center rounded-full border border-ember/30 px-5 font-semibold text-ember focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember`,children:`Report on GitHub Security ↗`}),s===`getting-started`&&(0,c.jsx)(e,{to:`/download`,className:`inline-flex min-h-11 items-center rounded-full bg-ember px-5 font-semibold text-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember`,children:`Choose a download`})]}),(0,c.jsx)(`aside`,{className:`border-t border-border pt-6 lg:border-l lg:border-t-0 lg:pl-6 lg:pt-0`,children:(0,c.jsxs)(`nav`,{"aria-label":`Resource pages`,className:`space-y-1 lg:sticky lg:top-28`,children:[(0,c.jsx)(`p`,{className:`mb-4 font-mono text-xs font-semibold uppercase tracking-wider text-muted-foreground`,children:`Explore the guides`}),l.map(n=>(0,c.jsx)(e,{to:t[n].path,"aria-current":s===n?`page`:void 0,className:`block rounded-lg px-3 py-3 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember ${s===n?`bg-ember/10 font-semibold text-ember`:`text-muted-foreground hover:bg-surface hover:text-foreground`}`,children:t[n].title},n)),(0,c.jsx)(e,{to:`/app`,className:`mt-4 block rounded-lg px-3 py-3 text-sm font-semibold text-ember focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ember`,children:`Open Web App →`})]})})]})]}),(0,c.jsx)(a,{})]})}export{d as t};