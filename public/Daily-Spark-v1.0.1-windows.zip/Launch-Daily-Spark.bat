@echo off
start "" "%~dp0Daily-Spark.exe"
if %errorlevel% neq 0 (
  start "" "%~dp0resources\app\index.html"
)
