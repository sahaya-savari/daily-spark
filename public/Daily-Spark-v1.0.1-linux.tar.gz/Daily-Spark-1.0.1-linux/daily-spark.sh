#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$SCRIPT_DIR/resources/app"

if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$APP_DIR/index.html"
elif command -v sensible-browser >/dev/null 2>&1; then
  sensible-browser "$APP_DIR/index.html"
else
  firefox "$APP_DIR/index.html" || google-chrome "$APP_DIR/index.html" || chromium-browser "$APP_DIR/index.html"
fi
