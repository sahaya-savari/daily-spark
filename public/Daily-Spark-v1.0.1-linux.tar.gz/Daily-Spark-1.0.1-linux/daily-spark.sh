#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVE_DIR="$SCRIPT_DIR/resources"
PORT=8765

if ! command -v python3 >/dev/null 2>&1; then
  echo "Daily Spark needs Python 3 to run its local offline server."
  echo "You can also use the web app at https://sahaya-savari.github.io/daily-spark/app"
  exit 1
fi

python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$SERVE_DIR" >/tmp/daily-spark.log 2>&1 &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM
sleep 1
APP_URL="http://127.0.0.1:$PORT/daily-spark/app"

if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$APP_URL"
elif command -v sensible-browser >/dev/null 2>&1; then
  sensible-browser "$APP_URL"
else
  firefox "$APP_URL" || google-chrome "$APP_URL" || chromium-browser "$APP_URL"
fi

wait "$SERVER_PID"
